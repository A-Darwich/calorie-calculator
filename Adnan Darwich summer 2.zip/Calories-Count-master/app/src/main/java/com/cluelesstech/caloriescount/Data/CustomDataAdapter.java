package com.cluelesstech.caloriescount.Data;

public class CustomDataAdapter{
}
